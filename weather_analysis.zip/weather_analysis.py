
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
import numpy as np

# Load data
df = pd.read_csv('weather_data.csv')

# Preprocess data
df['Date'] = pd.to_datetime(df['Date'])
df.sort_values('Date', inplace=True)
df['Day'] = (df['Date'] - df['Date'].min()).dt.days  # Convert date to numerical

# Plot historical data
plt.figure(figsize=(10, 5))
plt.plot(df['Date'], df['Temperature'], label='Historical Temperature')
plt.xlabel('Date')
plt.ylabel('Temperature')
plt.title('Temperature Over Time')
plt.legend()
plt.grid(True)
plt.show()

# Prepare features
X = df[['Day']]
y = df['Temperature']

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

# Train model
model = LinearRegression()
model.fit(X_train, y_train)

# Predict on test set
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)

print(f"Mean Squared Error: {mse:.2f}")

# Predict future temperatures
future_days = 30
last_day = df['Day'].max()
future_X = np.array([last_day + i for i in range(1, future_days + 1)]).reshape(-1, 1)
future_preds = model.predict(future_X)

# Plot future predictions
plt.figure(figsize=(10, 5))
plt.plot(df['Date'], df['Temperature'], label='Historical')
plt.plot(pd.date_range(start=df['Date'].max() + pd.Timedelta(days=1), periods=future_days), future_preds, label='Predicted Future', linestyle='--')
plt.xlabel('Date')
plt.ylabel('Temperature')
plt.title('Future Temperature Prediction')
plt.legend()
plt.grid(True)
plt.show()
